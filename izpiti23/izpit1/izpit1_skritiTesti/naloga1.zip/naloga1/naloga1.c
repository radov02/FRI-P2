/* #include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int main(int argc, char** argv){

    FILE* vhodna = fopen(argv[1], "rb");    // read binary
    FILE* izhodna = fopen(argv[2], "wb");

    char* bajt = calloc(2, sizeof(char));
    char* prejsnji = calloc(2, sizeof(char));

    bool prejsnji1B = false;
    bool zacetek = true;

    while(fread(bajt, 2, 1, vhodna) > 0){
        // printf("%s\n", bajt);
        if(prejsnji1B && strcmp(bajt, "C9") == 0){
            fwrite(bajt, 2, 1, izhodna);
            fprintf(izhodna, " ");
            prejsnji1B = false;
        }
        else if(strcmp(bajt, "1B") == 0){
            if(prejsnji1B && !zacetek){
                fwrite(prejsnji, 2, 1, izhodna);
                fprintf(izhodna, " ");
            }
            prejsnji1B = true;
        }
        else {
            if(prejsnji1B){
                fwrite(prejsnji, 2, 1, izhodna);
                fprintf(izhodna, " ");
            }
            prejsnji1B = false;
            fwrite(bajt, 2, 1, izhodna);
            fprintf(izhodna, " ");
        }
        prejsnji = bajt;
        fgetc(vhodna);  // presledek!
        zacetek = false;
    }

    if(prejsnji1B){
        fprintf(izhodna, "1B");
    }

    free(bajt);
    fclose(vhodna);
    fclose(izhodna);

    return 0;
} */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

int main(int argc, char** argv){
    // Open the input file in binary read mode
    FILE* vhodna = fopen(argv[1], "rb");    // read binary
    // Open the output file in binary write mode
    FILE* izhodna = fopen(argv[2], "wb");

    if (vhodna == NULL || izhodna == NULL) {
        fprintf(stderr, "Error opening file.\n");
        return 1;
    }

    // Allocate memory for a single byte
    unsigned char bajt;
    unsigned char prejsnji;

    bool prejsnji1B = false;

    // Read one byte at a time from the input file
    while(fread(&bajt, 1, 1, vhodna) > 0){
        // Check if the previous byte was 1B and the current byte is C9
        if(prejsnji1B && bajt == 0xC9){
            // Write C9 to the output file
            fputc(0xC9, izhodna);
            prejsnji1B = false;
        }
        // Check if the current byte is 1B
        else if(bajt == 0x1B){
            if(prejsnji1B){
                // Write the previous 1B byte to the output file
                fputc(0x1B, izhodna);
            }
            prejsnji1B = true;
        }
        else {
            if(prejsnji1B){
                // Write the previous 1B byte to the output file
                fputc(0x1B, izhodna);
            }
            prejsnji1B = false;
            // Write the current byte to the output file
            fputc(bajt, izhodna);
        }
        prejsnji = bajt;
    }

    // If the last byte was 1B, write it to the output file
    if(prejsnji1B){
        fputc(0x1B, izhodna);
    }

    // Free allocated resources and close files
    fclose(vhodna);
    fclose(izhodna);

    return 0;
}
